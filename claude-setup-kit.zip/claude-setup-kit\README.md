# Claude Code setup kit (Unity + learning-AI project)

Reproduces Tirth's Claude Code setup on another Windows machine.

## What's inside

| Folder | Goes to | Contents |
|---|---|---|
| `agents/` | `~/.claude/agents/` | 9 subagents: planner, architect, csharp-reviewer, code-reviewer, silent-failure-hunter, performance-optimizer, refactor-cleaner, pr-test-analyzer, type-design-analyzer |
| `skills/` | `~/.claude/skills/` | 34 skills: Matt Pocock engineering skills (tdd, grill-with-docs, code-review, ...), `improve`, Unity skills (unity-cli, ui-*, optimize-*, ...), and a few helper skills |
| `project-template/` | a new project folder | `CLAUDE.md` rulebook, `GLOSSARY.md`, `SKILLS-GUIDE.md`, `.gitignore` (Unity), `docs/agents/`, `docs/adr/` (5 starter decisions), agent ecosystem inventory |

The skills are real copies, not shortcuts, so they work anywhere.

## Prerequisites

- Claude Code installed and signed in (https://code.claude.com)
- Unity Hub + a Unity editor (for the Unity skills to be useful)
- Git

## Install

In PowerShell, from this folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 -ProjectPath C:\Games\MyGame
```

- Existing agents/skills are skipped; add `-Force` to overwrite them.
- Leave out `-ProjectPath` to install only the agents and skills.
- If you'd rather not run a script, copy `agents/*` and `skills/*` into `C:\Users\<you>\.claude\` by hand.

## Then, inside Claude Code

1. Install the ponytail plugin (a "lazy senior dev" mode):
   ```
   /plugin marketplace add DietrichGebert/ponytail
   /plugin install ponytail@ponytail
   ```
   Restart Claude Code afterwards.
2. In your project, run `git init`, then open Claude Code there.
3. Fill the `<placeholders>` at the top of `CLAUDE.md` (game name, deadline, Unity version, ...).
4. Run `/grill-with-docs` once to fill `GLOSSARY.md` and `docs/CONTEXT.md`. The template's glossary has TBD entries on purpose.

## Not included (and why)

- `settings.json`, history, sessions: personal; yours will be created automatically.
- Claude desktop app built-in skills (docs, pptx, pdf, ...) and connectors: they come with the app.
- Unity MCP / editor connection: set up with the `unity-cli` skill on your own machine.
- Files the template mentions but nobody has written yet: `docs/CONTEXT.md`, `docs/COMMANDS.md`, `notes/*`, `docs/playtest.md`.
