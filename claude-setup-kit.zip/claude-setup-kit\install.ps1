param(
  [string]$ProjectPath,   # optional: where to create the starter project (e.g. C:\Games\MyGame)
  [switch]$Force          # overwrite agents/skills that already exist
)

$kit = $PSScriptRoot
$claude = Join-Path $HOME ".claude"

function Install-Items($srcDir, $dstDir, $label) {
  New-Item -ItemType Directory -Force $dstDir | Out-Null
  foreach ($item in Get-ChildItem $srcDir) {
    $target = Join-Path $dstDir $item.Name
    if ((Test-Path $target) -and -not $Force) { Write-Host "skip   $label\$($item.Name) (exists, use -Force)"; continue }
    Copy-Item $item.FullName $target -Recurse -Force
    Write-Host "copied $label\$($item.Name)"
  }
}

Install-Items (Join-Path $kit "agents") (Join-Path $claude "agents") "agents"
Install-Items (Join-Path $kit "skills") (Join-Path $claude "skills") "skills"

if ($ProjectPath) {
  if ((Test-Path $ProjectPath) -and (Get-ChildItem $ProjectPath -Force | Select-Object -First 1)) {
    Write-Host "Project folder $ProjectPath is not empty; not copying the template."
  } else {
    New-Item -ItemType Directory -Force $ProjectPath | Out-Null
    Copy-Item (Join-Path $kit "project-template\*") $ProjectPath -Recurse -Force
    Copy-Item (Join-Path $kit "project-template\.gitignore") $ProjectPath -Force
    Write-Host "Project template copied to $ProjectPath"
  }
}

Write-Host ""
Write-Host "Done. Last step (inside Claude Code), to install the ponytail plugin:"
Write-Host "  /plugin marketplace add DietrichGebert/ponytail"
Write-Host "  /plugin install ponytail@ponytail"
Write-Host "Then restart Claude Code."
